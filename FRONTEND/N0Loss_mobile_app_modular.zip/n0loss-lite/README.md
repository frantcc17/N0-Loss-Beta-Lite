# N0Loss Lite — Frontend modular

App móvil de ahorro reorganizada en una arquitectura **modular** basada en
módulos ES nativos, **sin frameworks ni paso de build**. El diseño visual es
idéntico al original: solo cambió la organización del código.

## Cómo ejecutar

Al usar módulos ES (`<script type="module">`), el navegador **no permite abrir
`index.html` con doble clic** (`file://` bloquea los imports por CORS). Hay que
servir la carpeta con un servidor estático:

```bash
# Opción 1 — Python (viene preinstalado en la mayoría de sistemas)
cd n0loss-lite
python3 -m http.server 8080
# abre http://localhost:8080

# Opción 2 — Node
npx serve n0loss-lite
```

## Estructura

```
n0loss-lite/
├── index.html                  Shell mínimo: #app + el módulo de entrada
└── src/
    ├── main.js                 Punto de entrada: ensambla y arranca la app
    ├── config.js               Constantes (premios, importes, menú)
    ├── state.js                Estado global construido sobre el store
    │
    ├── core/                   Infraestructura reutilizable
    │   ├── store.js            Store reactivo (get / set / subscribe)
    │   ├── dom.js              Helpers de DOM: $, $$, el()
    │   ├── format.js           Formato de dinero, fechas e iniciales
    │   └── router.js           Navegación entre pantallas
    │
    ├── data/
    │   └── seed.js             Datos mock iniciales (movimientos)
    │
    ├── services/               Lógica de negocio (sin tocar el DOM)
    │   ├── auth.service.js     Login / registro / logout
    │   └── wallet.service.js   Depositar / retirar
    │
    ├── components/             Piezas de UI autónomas y reutilizables
    │   ├── Logo.js
    │   ├── Field.js            Input de formulario
    │   ├── Button.js           Botón (primary / ghost / danger)
    │   ├── Avatar.js           Iniciales, reactivo al usuario
    │   ├── UserName.js         Nombre, reactivo al usuario
    │   ├── TabBar.js           Navegación inferior, reactiva a la pantalla
    │   ├── Toast.js            Notificación efímera (controlador global)
    │   ├── BalanceCard.js      Saldo total + acciones
    │   ├── DrawCard.js         Próximo sorteo
    │   ├── MovementList.js     Lista de movimientos, reactiva
    │   ├── ProfileMenu.js      Menú de opciones
    │   └── Sheet.js            Hoja inferior depositar/retirar (controlador)
    │
    ├── pages/                  Pantallas completas que componen componentes
    │   ├── SplashPage.js
    │   ├── LoginPage.js
    │   ├── RegisterPage.js
    │   ├── DashboardPage.js
    │   └── ProfilePage.js
    │
    └── styles/                 CSS troceado por concern
        ├── index.css           Importa todos los parciales en orden
        ├── tokens.css          Variables de diseño (:root)
        ├── base.css            Reset, tipografía, utilidades, layout
        ├── buttons.css
        ├── components/         Un archivo por familia de componentes
        └── pages/              Un archivo por página
```

## Arquitectura en capas

El flujo de datos es unidireccional y las capas solo dependen hacia abajo:

```
  data (seed)  →  state (store)  →  services  →  components  →  pages  →  main
```

- **store**: única fuente de verdad. Los componentes leen con `store.get()` y
  reaccionan con `store.subscribe()`. Nadie muta el DOM "a mano" desde fuera.
- **services**: contienen la lógica de negocio (validar, calcular, actualizar
  estado) y devuelven `{ ok, error? }`. Aquí es donde conectarás una API real:
  bastará con cambiar el cuerpo de `auth.service.js` y `wallet.service.js` sin
  tocar la UI.
- **components**: se renderizan a sí mismos y gestionan sus propios eventos y
  suscripciones. Son reutilizables e independientes entre sí.
- **pages**: solo componen componentes; casi no tienen lógica.
- **router**: registra el nodo raíz de cada pantalla y muestra la activa según
  `state.screen`.

## Cómo extender

- **Nueva pantalla**: crea `pages/MiPagina.js`, instánciala en `main.js`,
  añádela al objeto `pages` y navega con `navigate('miPagina')`.
- **Nuevo componente**: crea `components/MiComponente.js` que devuelva un
  elemento; si necesita datos vivos, suscríbete al store dentro.
- **Backend real**: reemplaza el interior de los servicios por llamadas `fetch`
  (pueden ser `async`); la UI ya está desacoplada.
- **Nuevos importes rápidos / menú**: edita `config.js`.
